import pygame
import random
import math


WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (76, 175, 80)
DARK_GREEN = (56, 135, 60)
BLUE = (33, 150, 243)
PURPLE = (156, 39, 176)
ORANGE = (255, 152, 0)
GRAY = (200, 200, 200)
DARK_GRAY = (100, 100, 100)
GOLD = (255, 215, 0)
YELLOW = (255, 235, 59)
PINK = (233, 30, 99)

class DiceGame:
    def __init__(self, screen):
        self.screen = screen
        self.WIDTH = screen.get_width()
        self.HEIGHT = screen.get_height()
        
      
        self.font_title = pygame.font.Font(None, 72)
        self.font_large = pygame.font.Font(None, 48)
        self.font_medium = pygame.font.Font(None, 36)
        self.font_small = pygame.font.Font(None, 24)
        
       
        self.animation_progress = 0
        self.is_rolling = False
        self.roll_start_time = 0
        self.ROLL_ANIMATION_DURATION = 500
        self.dice_value = None
        self.result_text = "Нажми кнопку, чтобы бросить кубик!"
        self.rolling_values = []
        
        
        self.DICE_SIZE = 150
        self.DICE_X = self.WIDTH // 2 - self.DICE_SIZE // 2
        self.DICE_Y = self.HEIGHT // 2 - self.DICE_SIZE // 2 - 30
        
        
        self.button_rect = pygame.Rect(self.WIDTH // 2 - 100, self.HEIGHT - 120, 200, 60)
        self.button_hover = False
    
    def draw_gradient(self):
        for y in range(self.HEIGHT):
            color_value = 100 + int(155 * (y / self.HEIGHT))
            color = (color_value, 180, 230)
            pygame.draw.line(self.screen, color, (0, y), (self.WIDTH, y))
    
    def draw_dice_face(self, value, x, y, size=150, rotation_angle=0, scale=1.0):
        actual_size = int(size * scale)
        
        dice_surface = pygame.Surface((actual_size, actual_size), pygame.SRCALPHA)
        
        shadow_offset = max(3, int(5 * scale))
        shadow_alpha = int(80 * scale)
        shadow_surface = pygame.Surface((actual_size, actual_size), pygame.SRCALPHA)
        pygame.draw.rect(shadow_surface, (0, 0, 0, shadow_alpha), 
                        (shadow_offset, shadow_offset, actual_size, actual_size), 
                        border_radius=int(20 * scale))
        
        pygame.draw.rect(dice_surface, WHITE, (0, 0, actual_size, actual_size), 
                        border_radius=int(20 * scale))
        pygame.draw.rect(dice_surface, DARK_GRAY, (0, 0, actual_size, actual_size), 
                        max(2, int(3 * scale)), border_radius=int(20 * scale))
        
        dot_radius = max(5, actual_size // 12)
        dot_color = BLACK
        positions = {
            1: [(actual_size//2, actual_size//2)],
            2: [(actual_size//4, actual_size//4), (3*actual_size//4, 3*actual_size//4)],
            3: [(actual_size//4, actual_size//4), (actual_size//2, actual_size//2), 
                (3*actual_size//4, 3*actual_size//4)],
            4: [(actual_size//4, actual_size//4), (3*actual_size//4, actual_size//4), 
                (actual_size//4, 3*actual_size//4), (3*actual_size//4, 3*actual_size//4)],
            5: [(actual_size//4, actual_size//4), (3*actual_size//4, actual_size//4), 
                (actual_size//2, actual_size//2),
                (actual_size//4, 3*actual_size//4), (3*actual_size//4, 3*actual_size//4)],
            6: [(actual_size//4, actual_size//4), (3*actual_size//4, actual_size//4),
                (actual_size//4, actual_size//2), (3*actual_size//4, actual_size//2),
                (actual_size//4, 3*actual_size//4), (3*actual_size//4, 3*actual_size//4)]
        }
        
        for pos in positions.get(value, []):
            pygame.draw.circle(dice_surface, dot_color, pos, dot_radius)
            if dot_radius > 3:
                pygame.draw.circle(dice_surface, (220, 220, 220), 
                                  (pos[0]-dot_radius//3, pos[1]-dot_radius//3), 
                                  max(2, dot_radius//3))
        
        self.screen.blit(shadow_surface, (x, y))
        
        if rotation_angle != 0:
            rotated_surface = pygame.transform.rotate(dice_surface, rotation_angle)
            rect = rotated_surface.get_rect(center=(x + actual_size//2, y + actual_size//2))
            self.screen.blit(rotated_surface, rect.topleft)
        else:
            self.screen.blit(dice_surface, (x, y))
    
    def draw_button(self):
        mouse_pos = pygame.mouse.get_pos()
        self.button_hover = self.button_rect.collidepoint(mouse_pos)
        
        if self.button_hover:
            btn_color = DARK_GREEN
            shadow_offset = 2
            pulse = math.sin(pygame.time.get_ticks() * 0.008) * 0.1 + 0.9
        else:
            btn_color = GREEN
            shadow_offset = 4
            pulse = 1.0
        
        pygame.draw.rect(self.screen, DARK_GRAY, 
                        (self.button_rect.x + shadow_offset, self.button_rect.y + shadow_offset, 
                         self.button_rect.width, self.button_rect.height), 
                        border_radius=15)
        
        if pulse != 1.0:
            btn_color = tuple(int(c * pulse) for c in btn_color)
        
        pygame.draw.rect(self.screen, btn_color, self.button_rect, border_radius=15)
        pygame.draw.rect(self.screen, GOLD, self.button_rect, 2, border_radius=15)
        
        button_text = self.font_medium.render("Бросить кубик!", True, WHITE)
        text_rect = button_text.get_rect(center=self.button_rect.center)
        self.screen.blit(button_text, text_rect)
    
    def draw_particles(self):
        if self.is_rolling:
            center_x = self.WIDTH // 2
            center_y = self.HEIGHT // 2 - 30
            for i in range(30):
                angle = random.randint(0, 360)
                radius = 120 + int(math.sin(self.animation_progress * math.pi * 4 + i) * 30)
                x = center_x + math.cos(math.radians(angle + self.animation_progress * 20)) * radius
                y = center_y + math.sin(math.radians(angle + self.animation_progress * 20)) * radius
                colors = [GOLD, ORANGE, YELLOW, PINK]
                color = colors[i % len(colors)]
                size = random.randint(2, 5)
                pygame.draw.circle(self.screen, color, (int(x), int(y)), size)
                
                tail_x = int(x - math.cos(math.radians(angle + self.animation_progress * 20)) * 10)
                tail_y = int(y - math.sin(math.radians(angle + self.animation_progress * 20)) * 10)
                pygame.draw.line(self.screen, color, (int(x), int(y)), (tail_x, tail_y), 2)
    
    def start_roll(self):
        self.is_rolling = True
        self.roll_start_time = pygame.time.get_ticks()
        self.rolling_values = []
        self.result_text = "Бросаем кубик..."
    
    def update(self, dt):
        if self.is_rolling:
            current_time = pygame.time.get_ticks()
            elapsed = current_time - self.roll_start_time
            
            if elapsed >= self.ROLL_ANIMATION_DURATION:
                self.is_rolling = False
                self.dice_value = self.rolling_values[-1] if self.rolling_values else random.randint(1, 6)
                self.result_text = f"Выпало {self.dice_value}!"
                
                flash_surface = pygame.Surface((self.WIDTH, self.HEIGHT))
                flash_surface.fill(WHITE)
                flash_surface.set_alpha(180)
                self.screen.blit(flash_surface, (0, 0))
                pygame.display.flip()
                pygame.time.wait(50)
            else:
                self.animation_progress = elapsed / self.ROLL_ANIMATION_DURATION
                if elapsed % 50 < 16:
                    self.rolling_values.append(random.randint(1, 6))
                    if len(self.rolling_values) > 10:
                        self.rolling_values.pop(0)
    
    def draw(self):
        self.draw_gradient()
        
       
        title_shadow = self.font_title.render("COOLDICE", True, DARK_GRAY)
        title_text = self.font_title.render("COOLDICE", True, PURPLE)
        title_rect = title_text.get_rect(center=(self.WIDTH // 2, 60))
        self.screen.blit(title_shadow, (title_rect.x + 3, title_rect.y + 3))
        self.screen.blit(title_text, title_rect)
        
        if self.is_rolling:
            scale = 1 + math.sin(self.animation_progress * math.pi) * 0.15
            angle = self.animation_progress * 360 * 1.5
            current_dice = self.rolling_values[-1] if self.rolling_values else random.randint(1, 6)
            
            self.draw_dice_face(current_dice, self.DICE_X, self.DICE_Y, self.DICE_SIZE, angle, scale)
            self.draw_particles()
            
            anim_text = self.font_medium.render("Бросаем!", True, ORANGE)
            anim_rect = anim_text.get_rect(center=(self.WIDTH // 2, self.DICE_Y + self.DICE_SIZE + 40))
            self.screen.blit(anim_text, anim_rect)
            
        elif self.dice_value:
            self.draw_dice_face(self.dice_value, self.DICE_X, self.DICE_Y, self.DICE_SIZE)
            
            pulse = math.sin(pygame.time.get_ticks() * 0.005) * 0.15 + 0.85
            
            if self.dice_value == 6:
                result_color = GOLD
            elif self.dice_value == 1:
                result_color = ORANGE
            else:
                result_color = BLUE
            
            result_surface = self.font_large.render(self.result_text, True, result_color)
            result_rect = result_surface.get_rect(center=(self.WIDTH // 2, self.DICE_Y + self.DICE_SIZE + 40))
            self.screen.blit(result_surface, result_rect)
            
            glow_surface = self.font_large.render(self.result_text, True, GOLD)
            glow_surface.set_alpha(40)
            glow_rect = glow_surface.get_rect(center=(self.WIDTH // 2 + 2, self.DICE_Y + self.DICE_SIZE + 42))
            self.screen.blit(glow_surface, glow_rect)
            
            if self.dice_value == 1:
                tip_text = "Новая попытка? Удача на твоей стороне!"
                tip_color = DARK_GRAY
            elif self.dice_value == 6:
                tip_text = "Отлично! Максимальный результат!"
                tip_color = GOLD
            elif self.dice_value >= 4:
                tip_text = "Хороший результат! Так держать!"
                tip_color = ORANGE
            else:
                tip_text = "Попробуй ещё раз!"
                tip_color = DARK_GRAY
            
            tip_surface = self.font_small.render(tip_text, True, tip_color)
            tip_rect = tip_surface.get_rect(center=(self.WIDTH // 2, self.DICE_Y + self.DICE_SIZE + 85))
            self.screen.blit(tip_surface, tip_rect)
        else:
            self.draw_dice_face(1, self.DICE_X, self.DICE_Y, self.DICE_SIZE)
            start_text = self.font_medium.render(self.result_text, True, DARK_GRAY)
            start_rect = start_text.get_rect(center=(self.WIDTH // 2, self.DICE_Y + self.DICE_SIZE + 40))
            self.screen.blit(start_text, start_rect)
        
        self.draw_button()