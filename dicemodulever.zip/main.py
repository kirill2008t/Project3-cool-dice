import pygame
import sys
import math
from dice_game import DiceGame

def main():
    pygame.init()
    
    WIDTH = 800
    HEIGHT = 600
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Cooldice - Бросай кубик!")
    
    # Настройка иконки
    icon_surface = pygame.Surface((32, 32))
    icon_surface.fill((255, 255, 255))
    pygame.draw.rect(icon_surface, (50, 50, 50), (4, 4, 24, 24), 2)
    dot_positions = [(16, 16)]
    for pos in dot_positions:
        pygame.draw.circle(icon_surface, (0, 0, 0), pos, 3)
    pygame.display.set_icon(icon_surface)
    
    # Создание игры
    game = DiceGame(screen)
    clock = pygame.time.Clock()
    running = True
    
    while running:
        dt = clock.tick(60)
        
        # Обработка событий
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if game.button_rect.collidepoint(event.pos) and not game.is_rolling:
                    game.start_roll()
        
        # Обновление
        game.update(dt)
        
        # Отрисовка
        game.draw()
        pygame.display.flip()
    
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()